//#include<iostream>
//using namespace std;
//int fibonaaki(int n){
//	if(n==0||n==1)
//	{return n;
//	}
//	int a=fibonaaki(n-1);
//	int b=fibonaaki(n-2);
//		return a+b;
//	}
//int main(){
//	int num1,num2,n,i,temp;
//	cout<<"enter any 2 num to make series";
//	cin>>n;
//	for(i=1;i<n;i++)       //i=0 mai series "0" se shuru hoti haiii//
//	{
//		cout<<(fibonaaki(i))<<" ";
//	}
//		
//}
//

