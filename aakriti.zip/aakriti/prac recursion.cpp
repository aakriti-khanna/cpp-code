//#include<iostream>
//using namespace std;
//int ap(int t1,int d,int n)
//{	if(n==1)
//{	cout<<t1;
//	return 0;
//}
//	cout<<t1<<" ";
//	t1=t1+d;
//	ap(t1,d,n-1);
//}
//int main()
//{	int t1,t2,d,n;
//	cout<<"enter any 2 num to make series ";
//	cin>>t1>>t2>>n;
//	d=t2-t1;
//	ap(t1,d,n);
// }

//#include<iostream>
//using namespace std;
//int factorial(int num)
//{	if(num==1)
//{
//	return 1;
//}
//	return num*factorial(num-1);
//}
//	
//int main(){
//	int ans,n;
//	cout<<"enter any num ";
//	cin>>n;	
//	ans=factorial(n);
//	cout<<ans;
//	}
//	



//#include<iostream>
//using namespace std;
//int sum(int num)
//{	if(num==1)
//	{    
//		return 1;
//	}	
//	return  num+sum(num-1);
//}
//int main()
//{	int n,ans;
//	cout<<"enter any num";
//	cin>>n;
//	ans=sum(n);
//	cout<<ans;
//}
	














