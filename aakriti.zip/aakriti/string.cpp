#include<iostream>
#include<string.h>
using namespace std;
int main(){
	char arr[5];
	int index=-1,value,n;
	cin>>value;
	cout<<"\n enter an array";
	for(int i=0;i<n;i++){
		if(arr[i]==value)
		{
			index=i;
		}
		cout<<value<<" index value"<<index;
		
	}
//	int size;
//	size=strlen(name);
	
}
