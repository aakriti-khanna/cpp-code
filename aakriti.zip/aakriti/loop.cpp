#include<iostream>
using namespace std;
/*
int main(){
	int con;
	con=1;
	while(con<=10) 
	{
		cout<<"\n going for round:"<<con;
		con++;
	}
}
*/

int main(){
	int con;
	con=1;
	while(con<=10) 
	{
		cout<<"\n"<<con;
		con++;
	}
} 

/*
int main(){
	int con,num;
	cin>>num;
	con=1;
	while(con<=10) 
	{
		cout<<"\n"<<con*num;
		con++;
	}
} 
*/
/*

int main(){
	int con,sum,num;
	cin>>num;
	sum=0;
	con=1;
	while(con<=10) 
	{
	//	cout<<"\n"<<num<<"x"<<con<<"="<<con*num;
		sum+=con;
		con++;
	}
	cout<<"sum:"<<sum;
} 
*/




