#include<iostream>
using namespace std;
/*
int main(){
	int row,col;
	row = 0;
	
	while(row<=4)
	{	
		col = 0;
		while(col<=10)
		{
			cout<<" *";
			col++;
		}
		row++;
		cout<<endl;
	}
}
*/
/*
int main(){
	for(int i=0;i<=4;i++)
	{
		for(int j=0;j<=i;j++)
		{
			cout<<" *";
		}
		cout<<endl;
	}
} 
*/
/*
int main(){
	for(int i=0;i<=5;i++)
	{
		for(int j=5;j>i;j--)                                                                                                                                                                                                                     )
		{
			cout<<" ";
		}
		for(int j =0;j<=i;j++){
			cout<<"*";
		}
		cout<<endl;
	} 
}
*/

int main(){
	for(int i=0;i<=4;i++)
	{
		for(int j=0;j<=i;j++)
		{
			cout<<"*";
		}
	}
		cout<<endl;
	for(int i=0;i<=4;i++)
	{
			
		for(int j=0;j>i;j--)
		{
			cout<<" ";
		}
		for(int j=0;j<=i;j++)   
		{
			cout<<"*";
		}
	}
	cout<<endl;
	
}



















