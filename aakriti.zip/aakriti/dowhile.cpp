#include<iostream>
using namespace std;
/*
int main(){
	int con;
	con=1;
	do
	{
		cout<<" "<<con;
		con++;
	}while(con<=10);
}
*/
/*
int main(){
	int con,sum=0;
	con=1;
	do
	{
		sum+=con;
		con++;
	}while(con<=10);
	cout<<"sum"<<sum;
}
*/
/*
int main(){
	int temp,a,c,res=0;
	cout<<"enter a number : ";
	cin>>a;
	temp=a;
	 do
	 {
	 	c=a%10;
	 	res=res+(c*c*c);
	 	a=a/10;
	 }while(a>0);
	 cout<<res;
	 if(temp==res)
	 {
	 	cout<<"number is armstrong number.";
	 }
	 else
	 {
	 
	 	cout<<"number is not armstrong number.";
	 }
}
*/
int main(){
	int temp,n,a1,a2,con=0;
	cout<<"enter two numbers : ";
	cin>>a1>>a2;
	cout<<"enter number upto terms : ";
	cin>>n;
	do
	{
		cout<<" "<<a1;
		temp=a1+a2;
		a1=a2;
		a2=temp;
		
		con++;
		
	}while(con<=n);

}




