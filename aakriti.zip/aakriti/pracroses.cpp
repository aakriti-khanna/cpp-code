//#include<iostream>
//using namespace std;
//void bubblesort(int a[],int n){
//	for(int j=0;j<n-1;j++){
//		for(int i=0;i<n-1;i++){
//			if(a[i]>a[i+1]){
//				int temp=a[i];
//				a[i]=a[i+1];
//				a[i+1]=temp;
//				
//			}
//		}
//		
//	}
//}
//void pairofroses(int a[],int n,int rupay){
//	bubblesort(a,n);
//	int i=0,j=n-1;
//	
//	int rose1=-1,rose2=-1;
//	while(i<j){
//		if(a[i]+a[j]>rupay)
//		{
//			j--;
//		}
//		else if(a[i]+a[j]==rupay)
//		{
//			 rose1=a[i];
//			 rose2=a[j];
//
//			i++;
//			j--;
//		}
//		else
//		{
//			i++;
//		}
//	}
//	cout<<"Deepak should buy roses whose prices are"<< rose1 <<" and "<< rose2 <<"."<<endl;
//	}
//	
//	
//
//int main() {
//	int t;
//	cin>>t;
//	
//
//	for(int i=0;i<t;i++)
//	{
//		int a[100000];
//		int n,rupay;
//		cin>>n;
//	for(int i=0;i<n;i++)
//	{
//		cin>>a[i];
//	}
//	cin>>rupay;
//	pairofroses(a,n,rupay);
//	}



//
//}








#include<iostream>
using namespace std;
int main(){
	int n;
	n=5;
	int arr[5]={2,3,5,6,89};
	int value;
	int idx=-1;
	cin>>value;
	for(int i=0;i<n;i++){
		if(arr[i]==value)
		{
			idx=i;
		}
}
	
		cout<<value<<"index value"<< idx;
		
		
	
}










