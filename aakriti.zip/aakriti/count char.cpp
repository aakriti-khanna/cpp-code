//#include<iostream>
//using namespace std;
//int main(){
//	char ch;
//	int count=0;
////	cin>>ch;
//	ch=cin.get();
//	while(ch!='$'){
//		count++;
//	//	cin>>ch;
//	ch=cin.get();///////////////get function helps u too access whitespaces
//	}
//	cout<<"number of chracter : "<<count<<endl;
//}










#include<iostream>
using namespace std;
int main() {
	int n;
	cin>>n;
	n=(n+1)/2;
	for(int i=1;i<=(2*n)-1;i++)
	{
		cout<<"*"<<" ";
	}
	cout<<endl;
	for(int i=2;i<=n;i++){
		for(int j=i;j<=n;j++){
				
				cout<<"*"<<" ";
		}
		for(int k=1;k<=(2*i)-3;k++){
			
			cout<<" "<<" ";
		}
		for(int j=i;j<=n;j++){
			cout<<"*"<<" ";
		}
		cout<<endl;
		}

		for(int i=n-1;i>=2;i--){
		for(int j=i;j<=n;j++){
				
				cout<<"*"<<" ";
		}
		for(int k=1;k<=(2*i)-3;k++){
			
			cout<<" "<<" ";
		}
		for(int j=i;j<=n;j++){
			cout<<"*"<<" ";
		}
		cout<<endl;
		}
		for(int i=1;i<=(2*n)-1;i++)
		{
			cout<<"*"<<" ";
		}

}











