#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"enter two numbers"<<endl;
	cin>>a>>b;
	while(c>0)
	{
		a%c==0 && b%c==0;
		c++;
	}
	cout<<"HCF of two numbers are :"<<c;
}
