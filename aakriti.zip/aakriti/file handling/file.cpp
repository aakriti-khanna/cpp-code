#include<iostream>
#include<fstream>////////////////////////file ke liye//////////
using namespace std;
/*
open/create=>w,r,a
write/read=>
close=>
*/
/*
//how to write to file
*/
//ios::out//////write
//ios::in     //read
//ios::app //////////addition update
//ios::binary //////file,pic,access krne ke liye

//int main(){
//	string name =" jaskaran ";
//	ofstream fout;
//	fout.open("text.txt",ios::out);///koi new file open krwani hai &usme kch likhwana h
//	fout<<"hello "<<name;
//	fout.close();
//}

int main(){
	string name ="satvik ";
	ofstream fout;
	fout.open("text.txt",ios::app);///koi new update krna h
	fout<<"hello "<<name;
	fout.close();
}



//int main(){
//
//	char ch;
//	ifstream fin;
//	fin.open("text.txt",ios::in);///koi new file open krwani hai &usme kch likhwana h
//	while(!fin.eof()){
//		ch=fin.get();
//		cout<<ch;
//	}
//	fin.close();
//	
//}

//int main(){
//	char ch;
//	ifstream fin;
//	fin.open("text.txt",ios::in);///koi new file open krwani hai &usme kch likhwana hai
//	fout.open("text2.text",ios)
//	while(!fin.eof()){
//		ch=fin.get();
//		cout<<ch;
//	}
//	fin.close();
	
//}











