#include<iostream>
using namespace std;
int main(){
	int s,c,p;
	cin>>s>>c;
	p=s-c;
	cout<<"profit/loss is:"<<p;
}
