//#include<iostream>
//using namespace std;
//int main(){
//	for(int i=0;i<10;i++){
//		cout<<i<<" ";
//		if(i==4){
//		break; 
//		}
//	}
//}
//int main(){
//int n;
//cin>>n;
//for(int i=1;i<=n;i++){
//	for(int j=1;j<=i;j++)
//	{
//		cout<<"*";
//		
//	}
//		cout<<" ";
//	for(int k=n;k>=i;k--){
//		cout<<"*";
//	}
//	cout<<" ";
//	for(int k=n;k>=i;k--)
//	{
//		cout<<"*";
//	}
//	cout<<" ";
////	for(int i=1;i<=n;i++){
//	for(int j=1;j<=i;j++)
//	{
//		cout<<"*";
//		
//	}
//cout<<" ";
//	
//		cout<<endl;
//	}
//	
//
//}

//#include<iostream>
//using namespace std;
//#define PI 3.14 +1
////define MACRO_NAME MACRO_VALUE
////define print cout<<
////#define NEWLINE endl
//int main(){
//	int r=1;
////	PI=3.14;
//	cout<<2*PI*r<<endl;
//	//constant float pi=3.14+1;
//	//cout<<"using constant wala variable :<<2*pi*r<<endl;
//	
//}





//
//#include<iostream>
//using namespace std;
////int x=1000;
//int main(){
//	// cout<<x<<endl;
//	int x=1; ////////////////////////////change the variable with a
//	if (x>0){
//		int x=100;
//		cout<<x<<endl;
//	}
//	cout<<x<<endl;
//	//scope resolution operator-->::
////	::x=::x+1;
////	cout<<::x<<endl;
//
//	
//}

//#include <iostream>
////#include(cmath)
//using namespace std;
//int main()
//{
//    char ch;
//    ch = cin.get();
//    int x = 0, y = 0;
//    while (ch != '\n')
//    {
//        if (ch == 'N')
//        {
//            y++;
//        }
//        else if (ch == 'S')
//        {
//            y--;
//        }
//        else if (ch == 'E')
//        {
//            x++;
//        }
//        else
//        {
//            x--;
//        }
//        ch = cin.get();
//    }
//
//    if (x >= 0 && y >= 0)
//    {
//        for (int i = 0; i < x; i++)
//        {
//            cout << "E";
//        }
//        for (int i = 0; i < y; i++)
//        {
//            cout << "N";
//        }
//    }
//    else if (x <= 0 && y >= 0)
//    {
//        x = x * -1;
//
//        for (int i = 0; i < y; i++)
//        {
//            cout << "N";
//        }
//        for (int i = 0; i < x; i++)
//        {
//            cout << "W";
//        }
//    }
//    else if (x <= 0 && y <= 0)
//    {
//        x = x * -1;
//        y = y * -1;
//        for (int i = 0; i < y; i++)
//        {
//            cout << "S";
//        }
//        for (int i = 0; i < x; i++)
//        {
//            cout << "W";
//        }
//    }
//    else
//    {
//        y = y * -1;
//        for (int i = 0; i < x; i++)
//        {
//            cout << "E";
//        }
//        for (int i = 0; i < y; i++)
//        {
//            cout << "S";
//        }
//    }
//}


//
//#include<iostream>
//using namespace std;
//int main(){
//   int a[50];
//    int n;
//    cin>>n;
//    
//  for(int i=0;i<n;i++)
//  {
////        a[i]=i+1;
//   		cin>>a[i];
//  }
//   for(int i=0;i<n;i++)
//    {	
//        cout<<a[i];
//    }
//    cout<<endl;
//}


#include<iostream>
using namespace std;
int main(){
	int n,temp;
	int arr[]={5,4,3,2,1,7,10,-1};
	n=sizeof(arr)/sizeof(int);
    
	for(int j=0;j<n-1;j++){
		for(int i=0;i<n-1;i++){
        if(arr[i]>arr[i+1]){
		arr[i+1]=((arr[i+1]+arr[i])-(arr[i]=arr[i+1]));
//        	temp=arr[i];
//        	arr[i]=arr[i+1];
//       		 arr[i+1]=temp;
//            
        }
    }
    
}
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
}






