//#include<iostream>
//using namespace std;
//int main(){
//	int arr[2][5], sum=0;
//	cout<<" enter any num ";
//	for(int stu=0;stu<2;stu++)
//	{
//		cout<<"\n marks of student 1 and 2 :";
//		sum=0;
//		for(int sub=0;sub<5;sub++)
//		{  
//			cin>>arr[stu][sub];
//			sum=sum+arr[stu][sub];
//			
//		}	
//		cout<<" "<<sum;
//		
//	}
//}
