#include<iostream>
using namespace std;
int main(){
	int a,temp,res=0,c;
	cout<<"enter a number"<<endl;
	cin>>a;
	temp=a;
	while(a>0)
	{
			c=a%10;
			res=res+(c*c*c);
			a=a/10;
	}
	cout<<"armstrong number"<<a<<"is"<<res;
}
