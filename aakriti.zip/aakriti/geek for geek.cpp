//#include<iostream>
//using namespace std;
//int main(){
//	int arr[3];
//	cout<<"\n sum of array";
//	int sum=0;
//	for(int i=0;i<3;i++)
//	{	cin>>arr[i];
//		sum=sum+arr[i];
//		
//	}
//		cout<<" "<<sum;
//}



//#include<iostream>
//using namespace std;
//int total(int arr,int n){
//	int sum=0;
//	for(int i=0;i<n;i++)
//	{
//		sum=sum+arr[i];	
//	}
//	return sum;
//}
//int main(){
//	int arr[3],sum=0,i;
//	cout<<"\n sum of array";
//	cin>>arr[i];
//	sum=total(arr,3);
//		
//	cout<<" "<<sum;
//
//}


//#include<iostream>
//using namespace std;
//int main(){
//	int arr[4]={1,2,3,4};
//	cout<<"\n array ";
//	for(int i=0;i<4;)
//	{
//		cout<<" "<<arr[i];
//		i=i+2;
//	}
//	
//}


//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5],sum=1;
//	cout<<"\n array";
//	for(int i=0;i<5;i++)
//	{
//		cin>>arr[i];
//		sum=sum+arr[i];
//		
//	}
//		cout<<" "<<sum;
//}



//#include<iostream>
//using namespace std;
//int main(){
//	cout<<"enter any array";
//	int arr[4]={1,2,3,4};
//	int n;
//	for(int i=0;i<4;i++)
//	{
//		cout<<" "<<arr[i];
//	}
//}
//

//#include<iostream>
//using namespace std;
//int main(){
//	cout<<"enter any array";
//	int arr[4]={1,2,3,4};
//	int n;
//	for(int i=0;i<4;i++)
//	{
//		cout<<" "<<arr[i];
//	}

//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5]={2,3,4,7,8};
//	int n=5,index=-1,num;
//	num=11;
//	for(int i=0;i<n;i++)
//	{
//		if(arr[i]==num)
//		{	
//			index=i;
//			break;
//		}
//	}
//		cout<<"print the value of index"<<index;
//}
//key=3;
//arr[key];

//#include<iostream>
//using namespace std;
//int main(){
//	int i,n;
//	int arr[5]={0,2,1,2,0};
//	int count0=0,count1=0,count2=0;
//	for(int i=0;i<n;i++)
//	{
//		cin>>arr[i];
//	}
//	
//	for(int i=0;i<n;i++){
//	if(arr[i]==0)
//	{	count0++;	
//	}
//	else if(arr[i]==1)
//	{	count1++;
//	}
//	else 
//	{	count2++;
//	}
//}
//	for(int i=0;i<count0;i++){
//		arr[i]=0;
//	}	
//	for(int i=0;i<count1;i++){
//		arr[i]=1;
//	}
//	for(int i=0;i<count2;i++)
//	{
//		arr[i]=2;
//	}
//	}
		
//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5]={1,2,3,5,4}
//	int index[5]	
//	for(int i;i<n;i++)
//	{  
//		
//	}
//		
	
	
//#include<iostream>
//using namespace std;
//int getmax(int arr[],int n){
//	int max=INT_MIN;
//	for(int i=0;i<n;i++){
//		if(arr[i]> max)
//		{	
//			max=arr[i];
//		}
//	}	
//	return max;
//	
//}
//int getmin(int arr[],int n){
//		int min=INT_MAX;
//		for(int i=0;i<n;i++){
//		if(arr[i]<min)
//		{	
//			min=arr[i];
//		}
//	}	
//	return min;
//}
//
//int main(){	
//	int size=5,n;
//	cin>>size;
//	int arr[5];
//	for(int i;i<n;i++){
//		cin>>arr[i];
//	}
//	cout<<"max value"<<getmax(arr,size);
//	cout<<"min value"<<getmin(arr,size);
//	
//	
//}	
//	for(int i=0;i<n;i++){
//	
//	}
//
//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5],max,i;
//	cout<<" find out the max arr";
//	for(int i=0;i<5;i++)
//	{
//		cin>>arr[5];
//	}
//	max=arr[0];
//	for(int i=0;i<5;i++)
//	{	if(max<arr[i])
//		{
//			max=arr[i];
//		}
//	
//	}
//	cout<<" "<<max ;
//}
//

//#include<iostream>
//using namespace std;
//int total(){
//	int sum=0,n;
//	for(int i=0;i<=n;i++){
//		sum=sum+i;
//	}
//	return sum;
//}
//int main(){
//	int sum=0,n,ans;
//	cout<<"sum of all n numbers are";
//	cin>>n;
//	ans=total();
//	cout<<ans;
//	
//}

//#include<iostream>
//using namespace std;
//int main(){
//	int num,count=0;
//	cout<<"enter any num to find digit ";
//	cin>>num;
//	while(num>0){
//		num=num/10;
//		count++;
//	}
//	cout<<count;	
//}

























