#include<iostream>
using namespace std;
int main(){
	
	int a;
	cin>>a;
	if(a>90)
	{
		cout<<"\n"<<a<<" A+ ";
	}  
	else if(90>= a >80)
	{
		cout<<"\n"<<a<<"A";
	}
	else if (80>=a>70)
	{ 
		cout<<"\n"<<a<<"B";
	}
	else if (70>=a>60)
	{
		cout<<"\n"<<a<<"C";
	}
	else if (60>=a>50)
	{
		cout<<"\n"<<a<<"D";	
	}
	else if (50>=a>40)
	{
		cout<<"\n"<<a<<"E";
	}
	else
	{
		cout<<"\n"<<a<<"fail";
	}
	
}
