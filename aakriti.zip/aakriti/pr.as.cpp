#include<iostream>
using namespace std;;
int main(){
	int a,res=0,c,temp;
	a=temp;
	cout<<"enter a number:"<<endl;
	cin>>a;
	while(a>0)
	{
		c=a%10;
		res=res+(c*c*c);
		a=a/10;
	}
	cout<<"armstrong number"<<a<<"is"<<res;
}
