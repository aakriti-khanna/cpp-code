#include<iostream>
using namespace std;
void input(int arr[],int s){
	int i;
	cout<<"enter any 5 num";
	for(int i=0;i<s;i++)
	{
		cin>>arr[i];
	}
}
//int maximum(int arr[],int s){
//	int i,max;
//	max=arr[0];
//	for(i=0;i<s;i++)
//	{	
//		if(max<arr[i])
//		{
//			max=arr[i];
//		}
//		
//	} 
//	return max;
//	 
int total(int arr[],int s){
	int sum=0;
	for(int i=0;i<s;i++)
	{
		
		sum=sum+arr[i];
	}
	return sum;
}

int main()
{	int arr[5],sum=0,s;
	input(arr,s);
	sum=total(arr,5);
	cout<<" "<<sum;
}





//int main(){
//	int arr[5],max,i;
//	input(arr,5);
//	max=maximum(arr,5);	
//	
//	cout<<"max is"<<max;
//	
//}
