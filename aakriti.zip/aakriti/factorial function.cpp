#include<iostream>
using namespace std;
int factorial(int n){
	int f=1,i;
	for(i=1;i<=n;i++){
	f=i*f;
  	
  }
  
	return f;
	
}
int main(){
	int n,ans;
	cout<<"enter any num ";
	cin>>n;
	ans=factorial(n);
  	cout<<ans;
	
}
