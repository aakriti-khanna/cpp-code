//#include<iostream>
//using namespace std;
//int d(int num){
//	int num,digit;
//	digit=0;
//	while(num!=0)
//	{
//		num=num/10;
//		digit++;
//	
//	} 
//	return digit;
//	
//}
//int power(int num,int exp)
//	{
//		int count;
//		count=1;
//		int i=1;
//		while(count<=exp){
//		
//		i=i*num;
//		count++;
//	} 
//		return i;
//	}
//
//int main(){
//	
//	int num,digit,exp;
//	cout<<"enter any num and exp";
//	cin>>num>>exp;
//	
//		cout<<digit;
// }


///////////////////////// combination/////////////////////////////////
//int comb()
//{
//	
//	
//	
//	
//}
//
//int main(){
//	int n,r;
//	while(n>=)
//	{
//		n=n/r*(n-r);
//		
//		
//		
//		
//	}
//	
//	
//	
//	
//	
//}
//
//
//
//
//
//
//
//
//
//
//


//#include<iostream>
//using namespace std;
//int total(){
//	int sum=0,n;
//	cout<<"sum of all n numbers are";
//	cin>>n;
//	for(int i=1;i<=n;i++){
//		sum=sum+i;
//	}
//	return sum;
//}
//int main(){
//	int ans;
//	ans=total();
//	cout<<ans;
//	
//}
//
//
//
//








