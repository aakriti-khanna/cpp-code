#include<iostream>
using namespace std;
int main()
{	int *ptr,n,ext;             ////*ptr= pointer////
	cout<<"enter size : ";
	cin>>n;
	
	ptr=(int*)malloc(n*size of(int));
	if(ptr==null)
	{
		cout<<"memory not res";
	}
	else{
		cout("\n enter any num : ",n);
		for(int i=0;i<n;i++)
		{
			cin>>(ptr+i);
		}
		cout<<"\n array elements:"
		for(int i=0;i<n;i++)
		{	cout<<(*ptr+i)
		}
		
	}
}	
