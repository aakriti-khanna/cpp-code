#include<iostream>
using namespace std;
int main(){
	int a,b,c,d;
	d=a*b*c;
	cout<<"enter a number between 1 to 500"<<endl;
	cin>>d;
	d=1;
	while(d<=500)
	{
		if(d<=9)
		{
		//	cout<<"armstrong number is :"<<d*d*d;
		}
		else if (d>=10 && d<=99)
		{
			 //cout<<"armstrong number is :"<<a*a*a + b*b*b;
		}
		else
		{
		//	cout<<"armstrong number is :"<<a*a*a + b*b*b + c*c*c;
		}
		
	}
	if(d<=9)
		
		cout<<"armstrong number is :"<<d*d*d;
		
	else if (d>=10 && d<=99)
		
		cout<<"armstrong number is :"<<a*a*a + b*b*b;
		
	else
			cout<<"armstrong number is :"<<a*a*a + b*b*b + c*c*c;
}
