//#include<iostream>
//using namespace std;
//int getmax(int arr[],int n){
//	int max=INT_MIN;
//	for(int i=0;i<n;i++){
//		if(arr[i]>max)
//		{	
//			max=arr[i];
//		}
//	}	
//	return max;
//	
//}
//int getmin(int arr[],int n){
//	int min=INT_MAX;
//		for(int i=0;i<n;i++){
//		if(arr[i]<min)
//		{	
//			min=arr[i];
//		}
//	}	
//	return min;
//}
//
//int main(){	
//	int n=5;
//	int arr[5];
//	for(int i;i<n;i++){
//		cin>>arr[i];
//	}
//	cout<<"max value"<<getmax(arr,n);
//	cout<<"min value"<<getmin(arr,n);
//	
//	
//}	
//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5];
//	int n=5,max,i;
//	cout<<"enter any array";
//
//	for(int i=0;i<5;i++){
//		cin>>arr[i];
//	}
//	max=arr[0];
//	for(int i=0;i<5;i++){
//		if(arr[i]>max)
//	{
//		max=arr[i];
//	}
//	}
//	//return max;
//	cout<<max;
//}
//
//

//#include<iostream>
//using namespace std;
//int main(){
//	int arr[6]={0,1,2,2,4,},n=6;
//	cout<<"\n enter any array";
//	for(int i=0;i<n;i++)
//    {
//		cin>>arr[i]	;	
//	}
//	int count=0,value;
//	cout<<"enter any num to count";
//	cin>>value;
//	for(int i=0;i<n;i++)
//	{
//		if(arr[i]==value)
//		{
//			count++;
//		}
//	}
//	cout<<count;
//	
//}



#include<iostream>
using namespace std;
bool search(int arr[10],int size,int key){
	int value;
	for(int i=0;i<size;i++){
		if(arr[i]==value)
	{	
		return 1;
	}
	return 0;
}
}
int main(){
	int arr[8]={1,2,5,-4,17,45,88},value;
	cout<<"enter any value to found ";
	cin>>value;
	bool found=search(arr,10,value);
	{
		if(found)
		{	
			cout<<"value is present";
		}
		else
		{	
			cout<<" value is not present";
		}
		
		
	}
	
}














