#include<iostream>
using namespace std;
int main(){
	int p,l,c,s;
	cin>>c>>s;
	p=s-c;
	l=c-s;
	if(s>c)
	{
		p=s-c;
		cout<<"\n"<<"profit is :"<<p;
	}
	else
	{
		l=c-s;
		cout<<"\n"<<"loss is :"<<l;
	}
}
