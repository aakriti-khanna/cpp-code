#include<iostream>

using namespace std;

int main(){
	
	int start = 1,end=100;
	for(int i=start;i<end;i++){
		bool flag = true;
		for(int j=2;j<i;j++){
			if(i%j==0){
				flag=false;
				break;
			}
		}
		if(flag){
			cout<<i<<endl;
		}
	}
}









