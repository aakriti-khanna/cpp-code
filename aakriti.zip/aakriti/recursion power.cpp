#include<iostream>
using namespace std;
int power(int num,int exp){
	if(exp==1)
	{	return num;
	}
	return num*power(num,exp-1);
}
int main(){
	int num,exp,ans,n;
	cout<<"enter any num and exp";
	cin>>num>>exp;
	ans=power(num,exp);
	cout<<ans;
}


