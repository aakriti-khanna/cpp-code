#include<iostream>
using namespace std;
int main(){
	int a,b,c;
	cout<<"enter number of calls per month"; 
	cin>>a;
	if(a<=100)
	{
		b=200;
	cout<<"\n"<<"telephone bill of the month is : "<<b;	
	}
	else if (a>100 && a<=150)
	{
		c=a-100;
		b=200+(0.60*c);
		cout<<"\n"<<"telephone bill of the month is : "<<b;
	}
	else if (a>150 && a<=200)
	{
		c=a-150;
		b=200+(0.60*50)+(0.50*c);
		cout<<"\n"<<"telephone bill of the month is : "<<b;
	}
	else
	{
		c=a-200;
		b=200+(0.60*50)+(0.50*50)+(0.40*c);
		cout<<"\n"<<"telephone bill of the month is : "<<b;
	}
}
