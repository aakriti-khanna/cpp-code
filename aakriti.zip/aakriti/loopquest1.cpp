#include<iostream>
using namespace std;
//question2 below;
/*
int main(){
	int sum,con;
	sum=0;
	con=1;
	while(con<=10)
	{
		sum+=con;
		con++;
	}
	cout<<"sum"<<sum;
}
//question1 below;
*/
//int main(){
//	int con;
//	con=1;
//	while(con<=10)
//	{
//		cout<<con<<endl;
//		con++;
//	}
//}
/*
//question3:
int main(){
	int mul,st,end;
	cin>>st;
	end=1;
	mul=1;
	while(st>=end)
	{
		mul*=end;
	 	end++;
	}
	cout<<"\n factorial is :"<<mul;
}
*/
//question4:
int main(){
	int num,usd,b,mul,con;
	cout<<"enter second number :"<<endl;
	 usd=1;
	 mul=1;
	 while(con<=b)
	 {
	 	cout<<"\n  enter first number";
	 	cin>>num;
	 	mul*=num;;
	 }
	cout<<"\n first num raised to the power second number is :"<<mul;
}








