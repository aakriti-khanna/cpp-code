//#include<iostream>
//using namespace std;
//#define pi 3.14
//#define ar(r) pi*r*r
//int main()
//{	float r;
//	cout<<"enter the readius";
//	cin>>r;
//	cout<<"area"<<ar(r);
//	
//////////////////////////cube/////////////////////////
//#include<iostream>
//using namespace std;
//#define pi 3.14
//#define cube(r) r*r*r
//int main()
//{	float r;
//	cout<<"enter number";
//	cin>>r;
//	cout<<" cube "<<cube(r);
//	
//}
//
//
//
//



