#include<iostream>
using namespace std;
int main(){
	int con,num,mul;
	cin>>num;
	con=1;
	while(con<=num)
	{
		cout<<"\n"<<con*num;
		mul*=con;
		con++;
	}
}
