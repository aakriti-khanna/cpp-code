#include<iostream>
#include<math.h>
using namespace std;
int main(){
	int a,b,c,x,y;
	float d;
	cout<<"enter coefficient of x^2,x and constant of the equation"<<endl;
	cin>>a>>b>>c;
	if(a!=0)
	{
	d=(b*b)-4*a*c;
	x=(-b + sqrt(d))/(2*a);
	y=(-b - sqrt(d))/(2*a);
	cout<<"\n"<<"roots of the quadratic equation having these coefficient and constant will be : "<<x<<y;
}
	else
	{
		cout<<"\n"<<"equation is not quadratic.";
	}
}
