#include<iostream>
using namespace std;
int main()
{
	int usd,d,flag;
	//d=denominator;
	cout<<"enter a number :";
	cin>>usd;
	d=2;
	while(d<usd)
	{
		if(usd%d==0)
		{
			flag=1;
			break;
			
//			cout<<"number is not prime number :";
		}
		else
		{
			flag=0;
//			cout<<"number is prime number :";
		}
		d+=1;
	}
	if(flag==1)
		cout<<"Number is Not a Prime Number"<<endl;
	else
		cout<<"Number is a Prime Number"<<endl;
}
