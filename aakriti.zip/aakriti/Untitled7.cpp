//#include<iostream>
//using namespace std;
//int sum(){
//	int sum=0,i=1,n;
//	cout<<"enter any num to make series ";
//	cin>>n;
//	for(i=1;i<=n;i++){
//	sum=sum+i;
//	}
//	cout<<sum;
//	
//}
//
//int main(){
//	sum();
//	
//} 
