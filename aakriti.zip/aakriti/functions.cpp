#include<iostream>
using namespace std;

/*
//ap series
void sub(int a1,int a2,int n)
{	int d,con=1;
	d=a2-a1;
	while(con<=n)
	{
		cout<<"\nap series : "<<a1;
		a1=a1+d;
		con++;
	}
	
}
int main()
{
	int a1,a2,n;
	cout<<"\n enter two numbers : ";
	cin>>a1>>a2;
	cout<<"\nenter number of terms : ";
	cin>>n;
	cout<<"\n we are calling sub function";
	sub(a1,a2,n);
	cout<<"\n back to main";
}
*/
/*
//fibonacci series
void add(int a1,int a2,int n)
{
	int con=1,temp=1;
	while(con<=n)
	{
		cout<<"\n"<<a1;
		a1=a2;
		a2=temp;
		temp=a1+a2;
		con++;
	}
}
int main()
{
	int a1,a2,n;
	cout<<"enter two numbers : ";
	cin>>a1>>a2;
	cout<<"enter number of terms : ";
	cin>>n;
	cout<<"we are calling add function";
	add(a1,a2,n);
}
*/
 /*
//sum of natural numbers
int add()
{
	int sum=0,con=1,n;
	cout<<"\nenter number of terms : ";
	cin>>n;
	while(con<=n)
	{
		sum +=con;
		con++;
	}
	return sum;
}
int main()
{
	int sum;
	cout<<"\nwe are calling add function";
	sum=add();
	cout<<"\n sum is : "<<sum;
}
*/
/*
//prime numbers
void add(int st,int end)
{
	int d,con,flag=0;
	con=st;
	while(con<=end)
	{
		flag=0;
		d=2;
		while(d<con)
		{
			if(con%d==0)
			{
				flag=1;
				break;
			}
			d+=1;
		}
		if(flag==0)
		
			cout<<"\t"<<con;
			con++;
		
	}

}
int main()
{
	int st,end;
	cout<<"enter two numbers : ";
	cin>>st>>end;
	cout<<"\n we are calling add function";
	add(st,end);
}
*/
/*
//reverse
int add()
{
	int r,rev,a;
	cout<<"\n enter a number : ";
	cin>>a;
	while(a>0)
	{
		r=a%10;
		rev=r+rev*10;
		a=a/10;
	}	
	return rev;
}
int main()
{
	int rev;
	cout<<"\n we  are calling add function";
	rev=add();
	cout<<"\n reverse is : "<<rev;
}
*/
/*
//palindrome
int add()
{
	int r,rev,a,org;
	cout<<"\n enter a number : ";
	cin>>a;
	org=a;
	while(org>0)
	{
		r=org%10;
		rev=r+rev*10;
		org=org/10;
	}
	
	if(a==rev){
		return 1;
	}
	else{
		return 0;
	}
}
int main()
{
	int rev;
	cout<<"\n we  are calling add function";
	rev=add();
	if(rev==1)
	{
		cout<<"the number is palindrome";
	}
	else
	{
		cout<<"the number is not palindrome";
	}
}
*/
/*
//number of digits
int add()
{
	int a,con;
	cout<<"\n enter a number : ";
	cin>>a;
	con=0;
	while(a>0)
	{
		a=a/10;
		con++;
	}
	return con;
}
int main()
{
	int ans;
	cout<<"\n we are calling add function";
	ans=add();
	cout<<"\n ans is : "<<ans;
}
*/

//power
int add()
{
	int a,b,con;
	cout<<"enter a number : ";
	cin>>a;
	cout<<"enter power of a number : ";
	cin>>b;
	while(b>0)
	{
		
	}
	
}
int main()
{
	
}




















