//#include<iostream> 
//using namespace std;
//int main(){
//	int arr[5],avg,i,n=5,sum=0;
//	cout<<"enter any  num ";
//	for(int i=1;i<=5;i++)
//	{ 
//		cin>>arr[i];
//		sum=sum+arr[i];
//		
//	}
//	avg=sum/n;
//	cout<<" "<<avg;
//	}
