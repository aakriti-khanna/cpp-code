#include<iostream>
using namespace std;
int main(){
	int con,num1,num2,mul;
	cin>>num1>>num2;
	mul=1;
	con=num1;
	while (con<=num2)
	{
		cout<<"\n"<<con*con;
		con++;
	}
}
