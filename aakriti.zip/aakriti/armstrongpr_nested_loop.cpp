#include<iostream>

using namespace std;

int main(){
	int a,temp,c,counter,res=0,val;
	cout<<"Enter a Number :";
	cin>>a;
	temp = a;
	for(counter=0;temp>0;counter++){
		temp/=10;
	}
	temp = a;
	while(temp > 0){
		c = temp % 10;
		val = 1;
		for(int i=0;i<counter;i++){
			val *= c;
		}
		res += val;
		temp /= 10;
	}
	if(res == a)
		cout<<a<<" is an Armstrong Number"<<endl;
	else
		cout<<a<<" is not an Armstrong Number"<<endl;
	
}
