#include<iostream>
using namespace std;
int main(){
	int arr[2][5],max;
	cout<<"enter any 5 num";
	for(int stu=0;stu<2;stu++)
	{	cout<<"enter marks of 2 student";
	max=arr[2][0];
	for(int sub=0;sub<5;sub++)
	
	{	if(max<arr[stu][sub])
		{	cin>>arr[stu][sub];
			max=arr[stu][sub];
		}
	}
		cout<<" max is "<<max;
	}
}
