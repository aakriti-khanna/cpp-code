#include<iostream>
using namespace std;
int main(){
	int con,mul;
	mul=1;
	con=1;
	while (con<=10)
	{
		mul*=con;
		con++;
	}
	cout<<"mul"<<mul;
}
