#include<iostream>
using namespace std;

class home{
	public : 
			int ht,wt;
			string name;
	home(){
			cout<<"enter name, ht , wt :";
			cin>>name>>ht>>wt;
		  }	
	void show(){
			cout<<"\n class function show :";
			cout<<"\n name : "<<name<<"\n height : "<<ht<<"\n weight : "<<wt;
		}
	void greet(){
		cout<<"\n hello mumbaii ";		
	}	
	friend void pooja(home &)	;  			
};
void pooja(home &ob){
	ob.greet();
	cout<<"\n name :"<<ob.name<<"\n height :"<<ob.ht<<"\n weight :"<<ob.wt;
	cout<<"\n changed value by friend function ";
	ob.ht=150;
	ob.wt=50;
	ob.name="aakriti ";
	cout<<"\n name :"<<ob.name<<"height :"<<ob.ht<<"weight :"<<ob.wt;
}
int main(){
	home ak;
	ak.show();
	pooja(ak);
	ak.show();
	
}
