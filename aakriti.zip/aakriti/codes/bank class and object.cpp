//account 
//name 
//branch
//balance
//show function
//deposit
//withdraw
//change name 
//change branch

#include<iostream>
using namespace std;
class bank{
	public:	
			int acc,balance;
			string name,branch;
			
		bank()
		{
			cout<<"\n construction called ";
			cout<<"\n enter any name,acc,branch,balance : ";
			cin>>name>>acc>>branch>>balance;
			cout<<"/n object value created :";
		}	
	void deposit(int amt){
		if(amt>0){
		balance=balance+amt;
		cout<<"\n "<<amt<<" has been successfully deposit"<<"\n new bal is "<<balance;
		}
		else{
				cout<<"amt should be more than zero";
			}
	}
	void withdraw(int amt){
		if (amt<=balance){
			balance=balance-amt;
			cout<<"\n "<<amt<<" has withdrawn successfully from account"<<"\n new bal is "<< balance;
		}
		else{
			cout<<"insufficient balance";
		}	
	}
	void change_name(string n){ 
		name=n;
		cout<<"\n name change successfully \n new name "<<name;
	}
	void change_branch(string b){
		branch=b;
		cout<<"\n branch change successfully \n new branch"<<branch;	
	}
	void show()
	{
		cout<<"\n name :"<<name<<"\n acc:"<<acc<<"\n branch :"<<branch<<"\n balance"<<balance;
	}	

};
int main(){
	bank ob1;
	ob1.show();
	ob1.deposit(40000);
	ob1.withdraw(20000);
	

	
}











