//
//#include<iostream>
//using namespace std;
//int main(){
//    int arr[5]={5,4,3,2,1,0,6};
//    int n=sizeof(a)/sizeof(int);
//    for(int j=0;j<n-1-j;i++){
//    for(int i=0;i<n-2;i++){
//        if(arr[i]>arr[i+1])
//        {
//           swap(arr[i],arr[i+1])
//        }
//    }
//    cout<<endl;
//}





//#include<iostream>
//using namespace std;
//int main(){
//
//    int arr[]={2,3,5,0,1,8,9,-1};
//    int n=sizeof(arr)/sizeof(int);
//    for(int idx=0;idx<n-1;idx++)
//	{	int min=idx;
//    	for(int i=idx+1;i<n;i++)
//		{
//    		if(arr[i]<arr[min])
//			{
//    			min=i;
//			}
//		}
//		swap(arr[min],arr[idx]);
//		
//	}
//	for(int i=0;i<n;i++)
//	{
//		cout<<arr[i]<<" ";
//	}
//	cout<<endl;
//}






#include<iostream>
using namespace std;
int main(){
	int arr[]={2,3,5,0,1,8,9,-1};
	int n=sizeof(arr)/sizeof(int),j;
   
    for(int i=1;i<n;i++)
	{	
		int hpc=arr[i];
		for(j=i-1;j>=0;j--)
		{	
			if(hpc<arr[j]){
				arr[j+1]=arr[j];
			}
			else{
				break;
			}
		
		
		}
		arr[j+1]=hpc;
	}
	
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
	cout<<endl;
}




