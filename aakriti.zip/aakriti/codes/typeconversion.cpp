//#include<iostream>
//using namespace std;
//
//int main(){
//    cout<<"'A'+ 'B'"<<'A'+'B'<<endl;
//    cout<<"'A'+0 : "<<'A'+0 <<endl;
//
//    char ch ='A';
//    char x=ch +1;
//    cout<<x<<endl;
//}
    
	
	
	
//	
//	
//	#include<iostream>
//using namespace std;
//
//int main(){
////	int a=1;
////    cout<<a++<<endl;
////    cout<<++a<<endl;
//	int a=3;
//    int x=100;
//    int y=--x;
//    int z=(a++)+(++a);////////////pre icrement : first add then update value and then add;
//    				////////////post increment : opp. of pre;
//    cout<<"x:"<<x<<endl;
//    cout<<"y:"<<y<<endl;
//    cout<<"z:"<<z<<endl;
//}       


//
//#include<iostream>
//using namespace std;
//int main(){
//	int n,num;
//	cin>>n;
//	int ans=0;
//	cout<<"enter numbers :";
//	for(int i=1;i<=n;i++)
//	{
//		cin>>num;
//		ans=ans^num;
//	}
//	cout<<"unique num :"<<ans<<endl;
//}


/////////////////////////////set bits/////////////////////////////////

//#include<iostream>
//using namespace std;
//int main(){
//	int count=0,rem;
//	int n=15;
//	while(n>0){
//		rem=n%2;
//		if(rem==1){
//			count++;
//		}
//		n=n/2;
//	}
//	cout<<"set bits "<<count<<endl;
//	
//}

#include<iostream>
using namespace std;
int main(){
int count=0,rem;
	int n=10;
	while(n!=0){
		
		if((n&1)==1){
			count++;
		}
		n=n>>1;
	}
	cout<<"set bits "<<count<<endl;
}

                                         




//
//#include<iostream>
//using namespace std;
//int main(){
//	
//	
//}
//







                                                                                                                         
