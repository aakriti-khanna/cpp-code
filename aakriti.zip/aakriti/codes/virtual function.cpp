//#include<iostream>
//using namespace std;
//
//class A{
//	public :
//		 virtual void f1()
//		{
//			cout<<"\n this is parent function 1 :";
//		}
//	
//		void f2()
//		{
//			cout<<"\n this is parent function 1 :";
//		}
//	
//};
//class B:public A{
//	public :
//	 void f1()
//		{
//			cout<<"\n this is child function 1 :";
//		}
//	
//	void f2()
//		{
//			cout<<"\n this is child function 2 :";
//		}
//	
//};
//
//int main(){
//	A ob1,*p;
//	B ob2;
//	p=&ob2;
//	p->f1();
//	p->f2();
//}







//#include<iostream>
//using namespace std;
//class A{
//		public :
//		virtual void area()=0;
//		virtual void peri()=0;
//};
//class B:public A{
//	public :
//		int ans,l,b;
//		void input(){
//			cout<<"\n area of rectangle and peri: ";
//			cout<<"\n length :";
//			cout<<"\n breadth :";
//			cin>>l>>b;
//		}
//		void area(){
//			ans=l*b;
//			
//		}
//		void peri()
//		{
//			ans=2*(l+b);
//		}
//		void show(){
//			cout<<ans;
//		}
//			
//	
//};
//int main(){
//		B obj1;
//		obj1.input();
//		obj1.area();
//		obj1.show();
//		obj1.peri();
//		obj1.show();
//}























