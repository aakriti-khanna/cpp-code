#include<iostream>
using namespace std;

class employee{

	public :
			int sal,id;
			string name,deptt ;
	void input()
	{	
		cout<<"\n enetr any name ,id, deptt,and sal";
		cin>>name>>id>>deptt>>sal;
		cout<<"employee started workin as per these value ";
	}
	void show()
	{
		cout<<"\n name :"<<name<<" id :"<<id<<" deptt :"<<deptt<<" sal :"<<sal;	
	}
};
int main(){
		employee obj1,obj2;
		obj1.input();
		obj2.input();
		obj1.show();
		obj2.show();
	}



//
//#include<iostream>
//using namespace std;
//class Employee{
//	
//	public :
//			int fees,roll;
//			string name,course;
//			
//	Employee()
//	{
//		cout<<"\n construction called";
//		 
//		cout<<"enter any data : ";
//		cin>>name>>roll>>fees>>course;
//		cout<<"\n object created with value";
//	}
//		
//	Employee(string n){
//		cout<<"\n\n1 parameter construction called";
//		name=n; 
//		cout<<"enter any data : ";
//		cin>>roll>>fees>>course;
//		cout<<"\n object created with value";
//	
//	}
//	Employee(string n,int r){
//		cout<<"\n\n2 parameter construction called";
//		name=n; 
//		roll=r;
//		cout<<"enter any data : ";
//		cin>>fees>>course;
//		cout<<"\n object created with value";
//		}
//	Employee(string n,int r,int f){
//		cout<<"\n\n3 parameter construction called";
//		name=n; 
//		roll=r;
//		fees=f;
//		cout<<"enter any data : ";
//		cin>>course;
//		cout<<"\n object created with value";
//		
//	}
//	Employee(string n,int r,int f,string c){
//		cout<<"\n\n4 parameter construction called";
//		name=n; 
//		roll=r;
//		fees=f;
//		course=c;
//		
//		cout<<"\n object created with value";
//		
//	}
//	void show()
//	{
//		cout<<"\n name :"<<name<<"roll :"<<roll<<" course:"<<course<<" fee :"<<fees;	
//	}
//
//	~Employee()
//	{
//		cout<<"\n object is destroying ";
//	}
//};
//int main(){
//	Employee ob1("aakriti"),ob2("aakriti",20),ob3("aakriti",20,5000),ob4("aakriti",20,5000,"c++");
//	ob1.show();
//	ob2.show();
//	ob3.show();
//	ob4.show();
//}
//









