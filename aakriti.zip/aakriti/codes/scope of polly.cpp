
#include<iostream>
using namespace std;
class bank{
	private:	
			int acc,balance;
			string name,branch;
	protected:		
		bank()
		{
			cout<<"\n construction called ";
			cout<<"\n enter any name,acc,branch,balance : ";
			cin>>name>>acc>>branch>>balance;
			cout<<"/n object value created :";
		}	
	void deposit(int amt){
		if(amt>0){
		balance=balance+amt;
		cout<<"\n "<<amt<<" has been successfully deposit"<<"\n new bal is "<<balance;
		}
		else{
				cout<<"amt should be more than zero";
			}
	}
	void withdraw(int amt){
		if (amt<=balance){
			balance=balance-amt;
			cout<<"\n "<<amt<<" has withdrawn successfully from account"<<"\n new bal is "<< balance;
		}
		else{
			cout<<"insufficient balance";
		}	
	}
	void change_name(string n){ 
		name=n;
		cout<<"\n name change successfully \n new name "<<name;
	}
	void change_branch(string b){
		branch=b;
		cout<<"\n branch change successfully \n new branch"<<branch;	
	}
	string getname()
	{
		return name;
	}
	void show()
	{
		cout<<"\n name :"<<name<<"\n acc:"<<acc<<"\n branch :"<<branch<<"\n balance"<<balance;
	}	

};
class user:public bank{
		public:
	void depo(){
		int amt;
			cout<<"\n deposit function called bc the site was protected :";
			cin>>amt;
			bank::deposit(amt);
			}
	void wd(){
			int amt;
			cout<<"\n withdraw function called bc the site was protected :";
			cin>>amt;
			bank::withdraw(amt);
		}
	void cn(){ 
		string n;
		cout<<"\n change name function called bc the above class is protected :";
		cin>>n;
		bank::change_name(n);
	}
	void cb(){
		string b;
		cout<<"\n change name function called bc the above class is protected :";
		cin>>b;
		bank::change_branch(b);
	}
		
	
	void show(){
		bank::show();
		string n;
		n=bank::getname();
		cout<<"\n"<<n;
	}
			
};
int main(){
	user ob2;
	ob2.depo();
	ob2.wd();
	ob2.show();
}


#include<iostream>
using namespace std;
class bank(){
	private:
			int account,deposit;
			string name,branch;
	protected:
	bank(){
				cout<<"construction value created ";
				cout<<"enter the deets of person name, branch,account,balance :";
				cin>>name>>branch>>account>>balance;
				cout<<"obj value created : ";
				}
	void deposit(){
			if(amt>0){
				balance=balance+amt;
				cout<<amt<<"has been successfully deposited"<<"\n new deposit"<<balance;
				cout<<"amt should be more than zero ";
				}
		}
	void 	  
};
int main(){
	
}









