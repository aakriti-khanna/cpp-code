#include<iostream>
using namespace std;
void merge(int a[], int n, int b[], int m){
    int i = n-1;
    int j = m-1;
    int k = m+n-1;

    while(i>=0 and j>=0){
        if(a[i] > b[j]){
            b[k] = a[i];
            i--;
            k--;
        }else{
            b[k] = b[j];
            j--;
            k--;
        }
    }
}

void Print(int a[], int n){
    for(int i=0; i<n; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int n = 3, m = 5;
    int b[8] = {1,2,5,7,9};
    int a[3] = {3,6,8};

    merge(a, n, b, m);
    Print(b, m+n);
}
