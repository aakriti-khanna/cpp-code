//#include<iostream>
//using namespace std;
//void bubblesort(int arr[],int n){
//
//	for(int i=0;i<n-1;i++){
//		for(int j=0;j<n-1-j;j++){
//			if(arr[j]>arr[j+1]){
//				swap(arr[j],arr[j+1]);
//			}
//		}
//	}
//}
//	void print(int arr[],int n){
//	for(int i=0;i<n;i++){
//		cout<<arr[i]<<" ";
//	}
//	cout<<endl;
//}
//
//int main(){
//	int arr[]={4,2,-18,30,45};
//	int n=sizeof(arr)/sizeof(int);
//	
//	bubblesort(arr,n);
//	print(arr,n);
//	
//
//}





#include<iostream>

using namespace std;

int main()
{
int number1, number2;
cin>>number1>>number2;
int count =0;
int i=0;
while(count<number1+1)
{

    int num = (3*i)+2;
    i++;
    if((num%number2)==0)
    {

    }
    else
    {
        cout<<num<<endl;
        count++;
    }

  }
}







