#include<iostream>

using namespace std;

int main()
{
	int n;
	cin>>n;
	int k=(n+1)/2;
	for(int i=1;i<=k;i++){
		for(int j=1;j<=k;j++){
		if(j==1||j==k||i==k)
		{
			cout<<"*";
		}
		else
		{
			cout<<" ";
		}
	}
	for(int j=k;j<n;j++){
		if(i==k||i==1)
	{
		
		cout<<"*";
	}
	else
	{
		cout<<" ";
	}
	}
	cout<<endl;
	
	}

	for(int i=k;i<n;i++){
	for(int j=k;j<=n;j++){
		if(i==n-1||j==n)
		{
			cout<<"*";
		}
		else
		{
			cout<<" ";
		}
	}
		for(int j=k;j<n;j++){
			if(j==n-1)
			{
				cout<<"*";
			}
			else{
				cout<<" ";
			}
		}
	
	cout<<endl;
}
}


