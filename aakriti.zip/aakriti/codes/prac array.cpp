//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5]={10,5,8,11,19};
//	int value,idx=-1;
//	cin>>value;
//	
//	for(int i=0;i<5;i++){
//		if(arr[i]==value){
//			idx=i;
//			break;
//		}
//	}
//	cout<<value<<" found at index"<<idx;
//}


//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5]={1,2,3,4,5};
//	int sum=0;
//	cout<<"\n array";
//	for(int i=0;i<5;i++)
//	{	cin>>arr[i];
//		sum=sum+arr[i];
//	}
//	cout<<sum;
//}

//
//
//
//#include<iostream>
//using namespace std;
//int max(int arr[],int n ){
//	int max=int min;
//	for(int i;i<n;i++){
//		if(arr[i]>max)
//		{
//			max=arr[i];
//		}
//	}
//	return max;
//	}
//	
//int min(int arr[],int n){
//	int min=int max;  
//	for(int i;i<n;i++){
//	if (arr[i]<min)
//	{
//		min=arr[i];
//	} 
//	}
//	
//}
//int main(){
//	int arr[5]={10,20,30,40,50}
//	int max,min ,i;
//	cout<<"find out the max and min num";
//	for(int i=0;i<n;i++){
//		cin>>arr[i]
//	}
//	cout<<"max is"<<max(arr,n);
//	cout<<"min is"<<min(arr,n);
//
//}


//#include<iostream>
//#include<string.h>
//using namespace std;
//int main(){
//	char arr[30],value;
//	int index=-1,n;
//	cout<<"\n enter an array : ";
//	gets(arr);
//	n=strlen(arr);
//	cout<<"\n enter any value and index  : ";
//	cin>>value;
//	for(int i=0;i<n;i++){
//		if(arr[i]==value)
//		{
//			index=i;
//			break;
//		}
//	
//	}
//	cout<<"\n"<<value<<" index value"<<index;
//	
////	int size;
////	size=strlen(name);
//	
//}

       //////////////array character function//////////////


//
//#include<iostream>
//#include<string.h>
//using namespace std;
//int find(char arr[],int n,char v)
//{	int index=-1;
//	for(int i=0;i<n;i++)
//	{
//		if(arr[i]==v)
//		{
//			index=i;
//		    break;
//		}	
//	}	
//	return index;
//}
//
//
//int main(){
//	char arr[30],v;
//	int index=-1,n,ans;
//	cout<<"\n enter an array : ";
//	gets(arr);
//	n=strlen(arr);
//	cout<<"\n enter any value and index  : ";
//	cin>>v;
//	ans=find(arr,n,v);
//	cout<<ans;
//	
//
//}
////////////////////////// find all index////////////////////////////
#include<iostream>
#include<string.h>
using namespace std;
int findall(char arr[],int size,char alpha,int index)
{ 	int index=-1;
	for(int i=index;i<size;i++)
	{
		if(arr[i]==alpha)
		{
			index=i;
		}
	}
	return index;
}
int main(){
	char arr[50],alpha;
	cout<<"\n enter any array : ";
	gets(arr);
	size=strlen(arr);
	cout<<"\n enter any alphabet : ";
	cin>>alpha;
	index=0;
	for(int i;i<size;i++)
	{
		index=find(arr,size,alpha,index)
		cout<<index
	}
	
	
	
	
	
	
	
}







