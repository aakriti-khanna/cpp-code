
////////////////////////////sort an array withut using array methods////
//#include<iostream>
//using namespace std; 
//void merge(int a[],int n,int b[],int m){
//	
//		int k=m+n-1;
//		int i=n-1;
//		int j=m-1;
//		while(i>=0&&j>=0){
//			if(a[i]>b[j])
//			{
//				b[k]=a[i];
//			
//				k--;
//				i--;
//			}
//		
//			else
//			{
//				b[k]=b[j];
//				k--;
//				j--;
//			}
//		}
//		while(j>=0){
//			a[k]=b[j];
//			k--;
//			j--;
//		}
//}
//	void print(int a[],int n){
//		for(int i=0;i<n;i++){
//			cout<<a[i]<<" ";
//		}
//		cout<<endl;
//	}
//
//
//int main(){
//	int a[3]={3,5,8};
//	int n=3;
//	int b[8]={1,2,6,7,9};
//	int m=5;
//	
//	merge(a,n,b,m);
//	print(b,m+n);
	
//}














#include<iostream>
using namespace std;
int main(){
	
int number1, number2;
cin>>number1>>number2;
int count =0;
//int i=0;
//while(count<number1+1)
	for(int i=1;i<count;i++)
{

    int num = (3*i)+2;
    
    if((num%number2)==0)
    {

    }
    else
    {
        cout<<num<<endl;
        count++;
    }

  }
}











