#include<iostream>
using namespace std;
//int fibonaaki(int num){
//	if(num>=1)
//	
//	
//	
//}
int main(){
	int a=0,b=1,c,i,n;
//	num1=0;
//	num2=1;
	cout<<"enter any two num to make series";
	cin>>a>>b>>n;
	cout<<a<<" "<<b;
	for(int i=1;i<n;i++)
	{ c=a+b;
	  a=b;
	  b=c;
	  
	   cout<<" "<<c; 		
	}
	
	
	
	
	
	
	
	
}
