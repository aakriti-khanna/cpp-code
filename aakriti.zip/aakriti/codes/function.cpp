//#include<iostream>
//using namespace std;

	///void printhello(): function declaration
//void input(){
//	cout<<"\n hello world !!";
//}
	////function definition
//
//int main(){
//
//	input(); //func calling/invoking

//}


//
//#include<iostream>
//using namespace std;
//void add(int a,int b)
//{	cout<<" addition is :";
//	cout<<a+b<<endl;
//
//}
//int main(){
//	add(2,3);
//}






//#include<iostream>
//using namespace std;
//	void printtable(int init,int fval,int step ){
//
//		while(far<=fval)
//		{
//			cout<<far<<" ";
//			c=(5*(far-32))/9;
//			cout<<c<<endl;
//			far=far+step;
//		}
//	}
//
//
//int main(){
////		int far=init,fval,step,c;
////		cin>>init>>fval>>step>>c;
//	printtable(0,200,10)
//}



#include<iostream>
using namespace std;
void sum(int a,int b){
	cout<<a+b<<endl;
}
int sum1(int a,int b){
	int ans;
	ans=a+b;
}
int main(){
	sum(10,20);
	int ans;
	ans=sum1(20,31);
	cout<<ans<<endl;
	if(ans%2==0)
	{
		cout<<"even ";
	}
	else{
		cout<<"odd ";
	}
}










