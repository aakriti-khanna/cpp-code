//#include<iostream>
//using namespace std;
//int main(){
//	char ch;
//	cin>>ch;
//	switch(ch){
//		case'N':
//		case'n':
//			cout<<"\n north ";
//			break;
//		case'S':
//		case's':
//			cout<<"\n south ";
//			break;
//		case'W':
//		case'w':
//			cout<<"\n west ";
//			break;
//		case'E':
//		case'e':
//			cout<<"\n east ";
//			break;
//		default:
//			cout<<"\n invalid input";
//	}
//}










