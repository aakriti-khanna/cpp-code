//#include<iostream>
//using namespace std;
//class A {
//		public:
//				int a,b,c;
//		void add(){
//			cout<<"enter any two num ";
//			cin>>a>>b;
//			c=a+b;
//		}
//		void show(){
//			cout<<"\n ans is"<<c;
//		}
//		
//};
//class B:public A{
//	public:
//		void add()
//		{
//			A::add();
//		}	
//		void add(int a,int b,int d)
//		{
//			c=a+b+d;
//		}
//		void add(int a,int b,int d,int e)
//		{	
//			c=a+b+d+e;
//		}
//};
//int main(){
//		B obj1;
//		obj1.add();
//		obj1.show();
//		obj1.add(3,4,5);
//		obj1.show();
//		obj1.add(2,4,5,6);
//		obj1.show();
//}

//#include<iostream>
//using namespace std;
//class A{
//		public:
//			A(){
//				cout<<"\n welcome to insurance policy ";
//				}
//};
//class B:public A{
//		public:
//				int theft,fire,acci,sum,disc;
//			void insurance(int theft){
//				cout<<"\n u have chosen the theft insurance package :";
//				sum=theft;
//			}
//			void show(){
//				cout<<"\n ans is "<<sum;
//			}
//			void insurance(int theft,int fire){
//				cout<<"\n u have chosen the theft and fire package :";
//				sum=theft+fire;
//			}
//			void insurance(int theft ,int fire ,int acci,int disc){
//				cout<<"\n u have chosen the theft ,fire and acci package:";
//				cout<<"\n by choosing 3 package providing a disc of :";
//				sum=theft+fire+acci-disc;
//			}
//};
//int main(){
//		B obj1;
//		obj1.insurance(5);
//		obj1.show();
//		obj1.insurance(5,6);
//		obj1.show();
//		obj1.insurance(5,6,8,2);
//		obj1.show();
//}


#include<iostream>
using namespace std;
class A{
		public:
				
			A(){
				cout<<" welcome to trends :";
			   }	
class B{
	  public:
			int western,indo western,boho,ethnic;
			void(int western){
			cout<<"\n u have chosen western clothes : ";
			sum=western;
			}
			void(int western,int indo western){
			cout<<"\n u have chosen western and indo western clothes : ";
			sum=western+indo western;
			}
			void(int western,int indo western,int boho){
			cout<<"\n u have chosen western ,indo western, boho,clothes : ";
			sum=western+indo western+boho;
			}
			void(western,indo western,int boho,int ethnic){
			cout<<"\n u have chosen western ,indo western, boho and ethnic clothes :";
				sum=western+indo western+boho+ethnic;
			}	
};				
int main(){
		
	
}
 
 
 
 
 
 
 
 
 
 








