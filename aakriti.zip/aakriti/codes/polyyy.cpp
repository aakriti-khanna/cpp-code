//#include<iostream>
//using namespace std;
//class A{
//		public : 
//				 int a,b,c;
//		void add(){
//			cout<<" enter any 2 num";
//			cin>>a>>b;
//			c=a+b;
//		}
//		void show(){
//			cout<<"ans is"<<c;
//		}
//		
//};
//class B:public A{
//		public:
//				int d;
//		void add(){
//			cout<<"enter 3 num";
//			cin>>a>>b>>d;
//			c=a+b+d;
//		} 
//};
//class C:public B{
//		public:
//				int e;
//		void add(){
//			cout<<"enter 4 num";
//			cin>>a>>b>>d>>e;
//			c=a+b+d+e;
//		}
//};
//int main(){
//	C obj1;
//	obj1.add();
//	obj1.show();
//	
//}


//
//#include<iostream>
//using namespace std;
//class A{
//		public : 
//				 int a,b,c;
//		void add(){
//			cout<<" enter any 2 num";
//			cin>>a>>b;
//			c=a+b;
//		}
//		void show(){
//			cout<<"ans is"<<c;
//		}
//		
//};
//class B{
//		public:
//				int x,y,z;
//		void add(){
//			cout<<"enter 2 num";
//			cin>>x>>y;
//			z=x+y;
//		} 
//		void show(){
//			cout<<"ans is"<<z;
//		}
//};
//class C:public A,public B{
//		public :
//				int call;
//		void add(){
//			cout<<"press 1 to call add of class A and press 2 to add of call B :";
//			cin>>call;
//			if(call==1)
//			{
//				A::add();
//				A::show();
//			}
//			else if (call==2)
//			{
//				B::add();
//				B::show();
//			}
//		
//	}
//};
//int main(){
//	C obj1;
//	obj1.add();
//}



//
//#include<iostream>
//using namespace std;
//class A{
//		public : 
//				 int a,b,c;
//		void add(){
//			cout<<" \n enter any 2 num to add";
//			cin>>a>>b;
//			c=a+b;
//		}
//		void show(){
//			cout<<"\n ans is"<<c;
//		}
//		
//};
//class B:public A{
//		public:
//			int a,b;
//		void sub()
//		{
//			cout<<"\n enter any 2 num to sub :";
//			cin>>a>>b;
//			c=a-b;
//		}
//};
//class C:public A{
//		public:
//				int a,b;
//		void multiply()
//		{
//			cout<<" \n enter any 2 num to multiply of class c";
//			cin>>a>>b;
//			c=a*b;
//		}
//		
//};
//int main(){
//	B obj1;
//	obj1.add();
//	obj1.show();
//	obj1.sub();
//	obj1.show();
//	C obj2;
//	obj2.add();
//	obj2.show();
//	obj2.multiply();
//	obj2.show();
//	
//}
//				
#include<iostream>
using namespace std;
class A{
		public : 
				 int a,b,c;
		void add(){
			cout<<" \n enter any 2 num to add";
			cin>>a>>b;
			c=a+b;
		}
		void show(){
			cout<<"\n ans is"<<c;
		}
		
};				
class B:public A{
		public:
		
		void sub()
		{
			cout<<"\n enter any 2 num to sub :";
			cin>>a>>b;
			c=a-b;
		}
};
class C{
		public:
			int x,y,z;
		void multiply(){
			cout<<"\n enter any 2 num to multiply :";
			cin>>x>>y;
			z=x*y;
		}
		void show(){
			cout<<"\n ans is"<<z;
		}
			
		
};
class D:public B,public C{
		public:
			int func;

			void divide(){
			cout<<"\n enter any 2 num to divide :";
			cin>>x>>y;
			z=x/y;
		}
		void show(){
			cout<<" press 1 to class A show func and press 2 to class show func :";
			cin>>func;
			if(func==1){
			
				A::show();
			}
			else if (func==2){
				
				C::show();
			}
			
		}
};

int main(){
	D obj1;
	B obj2;
	obj1.divide();
	obj1.show();
	obj1.multiply();
	obj1.show();
	obj2.add();
	obj2.show();
	obj2.sub();
	obj2.show();
	
	return 0;
	
}





