//#include<iostream>
//using namespace std;
//int main(){
//	int p,r,t,i;
//	cout<<"find simple intt";
//	cin>>p>>r>>t;
//	si=p*r*t;
//	{	
//		cout<<si;
//	}
//}

//#include<iostream>
//using namespace std;
//int main(){
//	float pie, r,area;
//	cout<<"find area of circle";
//	cin>>r>>pie;
//	area=pie*r*r;
//	{
//		cout<<area;
//	}
//	
//}
//#include<iostream>
//using namespace std;
//int main(){
//	int b,h,area;
//	cout<<"find area of triangle";
//	cin>>b>>h;
//	area=b*h/2;
//	{
//		cout<<area;
//	}
//	
//}
	

//#include<iostream>
//using namespace std;
//int main(){
//	float pie,r,p;
//	cout<<"find perimeter of circle";
//	cin>>pie>>r;
//	p=2*pie*r;
//	{
//		cout<<p;
//	}
//	
//}

//#include<iostream>
//using namespace std;
//int main(){
//	int even,odd,num;
//	cout<<"find the num is even or odd";
//	cin>>num;
//	if(num%2==0)
//	{
//		cout<<"num is even";
//	}
//	else
//	{	
//		cout<<"num is odd";
//	}
//
//
//}
//#include<iostream>
//using namespace std;
//int main(){
//	int year;
//	cout<<"enter any year";
//	cin>>year;
//	if(year%400==0)
//	{
//		cout<<year<<"its a leap year";
//	}	
//	else if(year%100==0)
//	{
//		cout<<year<<"its not a leap year";
//	}
//	else if(year%4==0)
//	{ 
//		cout<<year<<"its a leap year";
//	}
//	else
//	{ 	
//		cout<<year<<"its not a leap year";
//	}
//}

//#include<iostream>
//using namespace std;
//int main(){
//	int num1,num2 ,opr ;
//	 cout<< "  enter num1 and num2  ";
//     cin>>num1>>num2;
//    cout<<"press 1 to add, 2 to subtract , 3 to multiply, 4 to divide ";
//    cin>>opr;
//    switch (opr) 
//   {
//	 	case 1:
//    		cout<<"sum :"<<num1+num2 ;
//    		break;
//    	case 2:
//	        cout<<"sum:"<<num1-num2;
//			break;
//	    case 3:
//   	        cout<<"product :"<<num1*num2;
//	        break;
//	    case 4:    
//	     	cout<< "remainder :"<<float(num1)/num2;
//			break;
//		default:
//			cout<<"invalid choice ";
//			 break;
//    }
//}
//	 		

//#include<iostream>
//using namespace std;
//int main(){
//	int sum=0,n,i=1;
//	cout<<"enter any num";
//	cin>>n;
//	while(i<=n)
//	{
//		sum=sum+i;
//		i++;
//	}
//	cout<<sum;
//}

//int main(){
//	int sum=1,n,i=1;
//	cout<<"enter any num";
//	cin>>n;
//	while(i<=n)
//	{
//		sum=sum*i;
//		i++;
//	}
//	cout<<sum;
//}


//#include<iostream>
//using namespace std;
//int fibonacci(int n){
//	if(n==0||n==1)
//	{
//		return n;
//	}
//	int a=fibonacci(n-1);
//	int b=fibonacci(n-2);
//	
//	return a+b;
//	
//}
//int main(){
//	int num1,num2,n,ans;
//	cout<<" enter any num to make fibo series";
//	cin>>n;
//	for(int i=0;i<n;i++)
//	{
//		cout<<fibonacci(i)<<" ";
//	}
//}


//
//#include<iostream>
//using namespace std;
//int main(){
//	int arr[8],num1,num2,num3,n;
//	cout<<"\n array :";
//	cin>>num1>>num2>>n;
//	for(int i=0;i<n;i++)
//	{	arr[i]=num1;
//		num3=num1+num2;
//		num1=num2;
//		num2=num3;
//		
//	}
//	for(int i=0;i<n;i++)
//	{
//		cout<<" "<<arr[i];
//		
//	}
	
//	}

//#include<iostream>
//using namespace std;
//void array(){
//	
//	
//}
//
//int main(){
//	int arr[5];
//	cout<<"value at 1st index"<<arr[4];
//	cout<<endl<<"everything is ok";
//}
	
#include<iostream>
usng namespace std;
int main(){
	
}

























