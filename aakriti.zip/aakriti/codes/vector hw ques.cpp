#include<iostream>
#include<vector>
using namespace std;
int main(){
	vector<int> v;
	int num;
	int value=1; 

	while(value){	
	cout<<"enter any num";
	cin>>num;
	v.push_back(num);
	cout<<"enter any num if u want to add it 1/0 : ";
	cin>>value;
	}
	cout<<"vector size"<<v.size();
	cout<<"\n vector";
	cout<<"\n sum of number";
	int sum=0;
	for(int i;i<v.size();i++)
	{
	//	cout<<" "<<v[i] ;
		cin>>v[i];			
	}
	for(int i;i<v.size();i++)
	{
		sum=sum+v[i];
	}
		cout<<" "<<sum;
}

