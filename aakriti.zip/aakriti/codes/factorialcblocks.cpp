//#include<iostream>
//using namespace std;
//int fac(int n){
//	int pro=1;
//	
//	for(int i=1;i<=n;i++){
//		pro=pro*i;
//	}
//	return pro;
//	
//}
//int NCR(int n,int r){
//	int fac_n=fac(n);
//	int fac_r=fac(r);
//	int fac_nr=fac(n-r);
//
//	int ans= fac_n/(fac_r*fac_nr);
//	return ans;
//}
//
//int  main(){
//	int n,ans,r;
//	cout<<"enter any num :";
//	cin>>n>>r;
////	ans=fac(n);
//	ans=NCR(n,r);
//	cout<<ans<<endl;
//}














///////////swapping function(call by value)/////

#include<iostream>
using namespace std;

void numswap(int x,int y)
{
	swap(x,y);
	cout<<" a:"<<x<<" "<<" b :"<<" "<<y<<endl;
}

//void numswap(int &x,int &y)///////call by reference
//{
//	swap(x,y);
//}
int main(){
	int a=10,b=20;
//	cout<<" a:"<<a<<" "<<" b :"<<" "<<b<<endl;
	
	numswap(a,b);
//	cout<<" a:"<<a<<" "<<" b :"<<" "<<b<<endl;
	
}










