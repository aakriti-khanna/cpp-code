//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	for(int i=1;i<=n;i++){
//		for(int space=1;space<=n-i;space++)
//		{
//			cout<<" ";
//		}
//		int num=i;
//		for(int j=1;j<=i;j++)
//		{
//			cout<<num<<" ";
//			num++;
//		}
//		num=(2*i)-2;
//		for(int j=1;j<=i-1;j++)
//		{
//			cout<<num<<" ";
//			num--;
//		}
//		
//		cout<<endl;
//		
//	}
//	
//}


//int main(){
//	int n;
//	cin>>n;
//	for(int i=2;i<=n;i++){
//		bool flag=true;
//		for(int j=2;j<i;j++){
//			if(i%j==0){
//				flag =false ;
//				
//				break;
//			}
//		}
//		if(flag)
//		{
//			cout<<i;
//		}
//	}
//}

//
//int main(){
//	int n;
//	cin>>n;
//	int even=0,odd=1;
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=i;j++){
//			if(i%2==0){
//			
//			if(j%2==0)
//			{
//				cout<<1;
//			}
//			else{
//				cout<<0;
//			}
//		}
//		
//		else{
//			
//			if(j%2==0)
//			{
//				cout<<0;
//			}
//			else{
//				cout<<1;
//			}
//			
//		}
//	}
//		cout<<endl;
//	}
//}

//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	cout<<1<<endl;
//	for(int i=2;i<=n;i++){
//		for(int j=1;j<=i;j++)
//		if(j==1||j==i)
//		{	
//			cout<<i-1	;
//		}
//		else
//		{
//			cout<<0;
//		}
//		cout<<endl;
//	}
	
//}


#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	n=(n+1)/2;
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++)
		{
			cout<<"*"<<" ";
		}
		for(int k=1;k<=(2*n)-3;k++)
		{
			cout<<" "<<" ";
		}
		cout<<endl;
		for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++)
		{
			cout<<"*"<<" ";
		}
		for(int k=1;k<=(2*n)-3;k++){
			cout<<" "<<" ";
		}
			cout<<endl;
}
}
}







