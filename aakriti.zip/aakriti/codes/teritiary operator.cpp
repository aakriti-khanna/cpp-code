#include<iostream>
using namespace std;
int main(){
	int a=1;
	(a>0)?cout<<"\n hello":cout<<"\n world";
	bool b;
	b=(a%2==0)?true:false;
	b==true?cout<<"\n even":cout<<"\n odd";
}
