#include <iostream>
using namespace std;
int ap(){
int a,b,d,count,n;
	count=0;
	cout<<"enter any two num to make series";
	cin>>a>>b>>n;
	d=b-a;
	for(count=0;count<n;count++){
	cout<<a<<" ";
	a=a+d;

	}




}
int main(){
	
	ap();
	}



