//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5]={1,2,3,4,5};
//	cout<<"\n array : " ;
//	for(int i=0;i<5;i++)
//	{
//		cout<<" "<<arr[i];
//	}
//	
//}

//#include<iostream>
//using namespace std;
//int main()
//{	int arr[5],sum=0;
//	cout<<"enter any num :";
//	for(int i=0;i<5;i++)
//	{
//		cin>>arr[i];
//		sum=sum+arr[i];
//	}
//		cout<<" "<<sum;
//}
//


//#include<iostream>
//using namespace std;
//int main()
//{	int arr[5],num=1;
//	cout<<"enter any num :";
//	for(int i=0;i<5;i++)
//	{
//		cin>>arr[i];
//		num=num*arr[i];
//	}
//		cout<<" "<<num;
//}



