//#include<iostream>
//using namespace std;
//int main(){
//	
//	int i=0,j;
//	while(i<4){
//		j=0;
//		while(j<6){
//			
//			if(i%2==0){
//				if(j%2==0)
//					cout<<"*";
//				else
//					cout<<"#";
//			}
//			else{
//				if(j%2==0)
//					cout<<"#";
//				else
//					cout<<"*";
//			}
//			j++;
//		};
//		cout<<endl;
//		i++;	
//	};
//	
//
//}
