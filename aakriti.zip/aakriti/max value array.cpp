#include<iostream>
using namespace std;
int main(){
	int arr[5],max,i;
	cout<<"enter any 5 num";
	for(int i=0;i<5;i++)
	{
		cin>>arr[i];
	}
	max=arr[0];
	for(i=0;i<5;i++)
	{	if(max<arr[i])
		{
			max=arr[i];
		}
		
	}
	cout<<"max is"<<max;
	
}	
