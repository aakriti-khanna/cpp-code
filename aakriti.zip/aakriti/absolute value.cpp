#include<iostream>
using namespace std;
int main(){
	int a;
	cin>>a;
	if(a>0)
	{
		cout<<"\n"<<"the absolute value is :"<<a;
	}
	else if (a==0)
	{
		cout<<"\n"<<"the absolute value is :"<<a;
	}
	else
	{
		cout<<"\n"<<"the absolute value is :"<<-a;
	}
}
