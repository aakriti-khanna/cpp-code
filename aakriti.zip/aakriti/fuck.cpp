#include<iostream>
using namespace std;
int main(){
	int N , A[5];
    int sum =0;
    cout<<"enter any num : ";
     for(int i=0;i<5;i++)
	 {
     	cin>>A[i];
	 }
    for(int i=0;i<5;i++){
	
	sum=sum+A[i];
    }
	cout<<sum;
}
	
	
	
	
	

