#include<iostream>
using namespace std;
int main(){
	int a,b,c,con,n;
	cout<<"enter two numbers"<<endl;
	cin>>a>>b;
	cout<<"fibonacci value upto how many numbers :"<<endl;
	cin>>n;
	con=0;
	while(con<=n)
	{
		a=a+b;
		b;
		cout<<""<<a;
		con++;
	}
}
