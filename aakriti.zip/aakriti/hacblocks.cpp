//#include<iostream>
//using namespace std;
////int main(){
////	for(int i=1;i<=5;i++){
////		for(int j=1;j<=i;j++){
////			cout<<j<<" ";
////		}
////		cout<<endl;
////	}
////}
//int main(){
//	int n=5;
//	for(int i=6;i>=1;i--){
//		for(int space=6-i;space>0;space--)
//	{
//		cout<<" ";
//	}
//	for(int j=i;j>0;j--)
//	{
//			cout<<"*"<<" ";
//	}
//	
//		cout<<endl;
//	}
//}
//

//
//#include<iostream>
//using namespace std;
// int main(){
//	for(int i=1;i<=7;i++){
//		for(int j=1;j<=i;j++){
//			cout<<j;
//		}
//		
//	for(int space=1;space<=7-i;space++){
//	//	cout<<" ";
//		cout<<"*";
//	}
//	cout<<endl;
//	}
//}

//
//#include<iostream>
//using namespace std;
// int main(){
//	for(int i=1;i<=7;i++){
//		for(int j=1;j<=i;j++){
//			cout<<j*j;
//		}
//		
//	
//	cout<<endl;
//	}
//}
//


#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	n=(n+1)/2;
	for(int i=1;i<=n;i++){
		
		for(int space=1;space=2*(n-i);space++){
			cout<<" ";
		}
		int num=i;
		for(int j=1;j<=i;j++)
		{
			cout<<num<<" ";
			num--;
		}
		for(int space=1;space<=(2*i)-3;space++){
			cout<<" "<<" ";
		}
		num=1;
		if(i>=2){
			for(int j=1;j<=i;j++){
				cout<<num<<" ";
				num++;
			}
		}
		cout<<endl;
	}
	for(int i=n-1;i>=1;i--){
		int no=i;
		for(int space=1;space=2*(n-i);space++)
		{
			cout<<" "<<" ";
		}
		for(int num=1;num<=i;num++){
			cout<<no<<" ";
			no--;
		}
		
	}
}
			
			
			
			
			
			
			
		
		
		
			
		
	



