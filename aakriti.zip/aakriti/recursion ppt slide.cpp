//#include<iostream>
//using namespace std; 
//int ppt(int slide){
//	cout<<"\n ppt func"<<slide;
//	if(slide<=5)
//	{
//		return slide;
//	}	
//		return 5+ppt(slide-5);
//		
//}
//int main()
//{	int ans;
//	ans=ppt(32);
//	cout<<"\n slide printed :"<<ans;
//	
//}

//#include<iostream>
//using namespace std; 
//int sum(int num)  
//{ 
//	if (num==1)
//	{
//		return 1;
//	}
//	return num+sum(num-1);
//}
//	int main()
//	{	int ans,n=10;
//		ans=sum(n);
//		cout<<ans;
//		
//	}
//	





















