#include<iostream>
using namespace std;
int main(){
	int arr[5],min;
	cout<< "enter any 5 num";
	for(int i=0;i<5;i++)
	{	cin>>arr[i];
	}
	min=arr[0];
	for(int i=0;i<5;i++)
	{	
		if(min>arr[i])
		{	
			min=arr[i];
		}	
		
	}
	cout<<"min is"<<min;
}
