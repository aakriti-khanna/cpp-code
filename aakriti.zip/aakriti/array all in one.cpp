#include<iostream>
using namespace std;
void input(int arr[], int s){
	int i;
	cout<<"enter any num";
	for(i=0;i<s;i++)
	{
	cin>>arr[i];
    }
}
int total(int arr[],int s){
	int sum=0;
	for(int i=0;i<s;i++)
	{
		sum=sum+arr[i];
	}
	return sum;
	
}
int main(){
	int arr[5],ans,sum=0;
	input(arr,5);
	ans=total(arr,5);
	
	cout<<" "<<ans;
	
}
