#include<iostream>
using namespace std;
int main(){
	int n,con,flag=0;
	con=4;
	while(con<=100)
	{
		
		flag=0;
		n=2;
		while(n<con)
		{
			if(con%n==0)
			{
				flag=1;
				break;
			}
			n+=1;
		}
		if(flag==0)
		
			cout<<"\t"<<con;
			con++;
		
	}
	
}
