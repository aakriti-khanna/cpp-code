#include<iostream>
using namespace std;
int main(){
	int q,p,e,d;
	cin>>q>>p; 
	e=p*q;
	if(e<=5000)
	{
		e=q*p;
		cout<<"\n"<<"total expense is:"<<e;
	}
	
	else
	{
		e=(p*q)-0.1*(p*q);
		cout<<"\n"<<"total expense is :"<<e;
	}
}
