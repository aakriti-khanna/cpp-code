//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5];
//	int count=0,value,i;
//	cout<<"\n enter any array";
//	
//	for(int i=0;i<5;i++){
//		
//		cin>>arr[i];
//	}
//	cout<<"enter value to count";
//	cin>>value;
//	for(int i=0;i<5;i++){
//	if(arr[i]==value)	
//	{	
//		count++;
//	}
//	
//	}
//	cout<<count;
//	
//}
