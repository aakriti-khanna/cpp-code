#include<iostream>
using namespace std;
int main(){
	int q,p,e,d;
	cin>>q>>p;
	if(e<=5000)
	{
		e=q*p;
		cout<<"\n"<<e<<"total expense is:";
	}
	
	else
	{
		e=(p*q)-0.1*(p*q);
		cout<<"\n"<<e<<"total expense is :";
	}
}
