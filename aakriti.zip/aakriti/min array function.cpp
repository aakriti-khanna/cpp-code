//#include<iostream>
//using namespace std;
//void input(int arr[],int s){
//	int i;
//	cout<<"enter any num";
//	for(i=0;i<s;i++)
//	{
//		cin>>arr[i];
//	}
//}
//int minimum(int arr[],int s){
//	int i,min;
//	min=arr[0];
//	for(i=0;i<s;i++)
//	{
//		if(min>arr[i])
//		{
//			min=arr[i];
//		}
//	}
//	return min;
//}
//int main(){
//	int arr[5],min;
//	input(arr,5);
//	min=minimum(arr,5);
//	
//	cout<<"min is"<<min;
//	
//}
