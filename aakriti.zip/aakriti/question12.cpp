#include<iostream>
using namespace std;
int main(){
	
	char ch,a;
	cout<<"enter a character: "<<endl;
	cin>>a;
	if(65<=a && 90>=a)
	{
		cout<<"character is of capital letter";
	}
	else if (97<=a && 122>=a)
	{
	cout<<"character is of small letter";
	}
	else if(48<=a && 57>=a)
	{
		cout<<"character is of numbers";
	}
	else if( (0<=a && 47>=a)||(58<=a && 64>=a)||(91<=a && 96>=a)||(123<=a && 127>=a) )
		cout<<"special character";
}
