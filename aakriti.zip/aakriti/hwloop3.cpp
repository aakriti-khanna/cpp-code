#include<iostream>
using namespace std;
int main(){
	int con,mul;
	con=35;
	while(con<=50)
	{
		cout<<"\n"<<con*con;
	
		con++;
	}
}
