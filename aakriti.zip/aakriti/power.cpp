#include<iostream>
using namespace std;
int main()
{
	int a,b,con,res;
	res=1;
	cout<<"enter two numbers : "<<endl;
	cin>>a>>b;
	con=1;
	while(con<=b)
	{
		res*=a;
		con++;
	}
	cout<<"a raised to the power b is :"<<res<<endl;
}
