#include<iostream>
using namespace std;
int main(){
	int a,b,c;
	cout<<"enter three angles of triangle (in degree)"<<endl;
	cin>>a>>b>>c;
	if(a+b+c==180)
	{
		cout<<"\n"<<"triangle is valid";
	}
		else
		{
			cout<<"\n"<<"triangle is not valid";
		}
}
