
////////////////////////accept and return/////////////////////////////////
//#include<iostream>
//using namespace std;
//int fibonacci(){
//	int num1,num2,n,temp,i;
//	cout<<"enter any two num to make series ";
//	cin>>num1>>num2>>n;
//	
//	for(i=1;i<n;i++){
//	cout<<num1<<" ";
//	temp=num1;
//	num1=num2;
//	num2=temp +num1;
//	}
//		
//}
//int main(){
//		int ans;
//		ans=fibonacci();
//	}

/////////////////////do not accept,return///////////////////////////
//#include<iostream>
//using namespace std;
//void fibonacci(int num1,int num2,int n){
//	int temp,i;
//	
//	
//	for(i=1;i<n;i++){
//	cout<<num1<<" ";
//	temp=num1;
//	num1=num2;
//	num2=temp +num1;
//	}
//	return 5;	
//}
//int main(){
//	int num1,num2,n;
//	
//	cout<<"enter any two num to make series ";
//	cin>>num1>>num2>>n;
//	fibonacci(num1,num2,n);
//	}



#include<iostream>
using namespace std;
int 
int main(){
	int num1,num2,n,i,temp;
	cout<<"enter any 2 num to make series";
	cin>>num1>>num2>>n;
	cout<<num1<<" "<<num2;
	for(i=1;i<n;i++)
	{	temp=num1;
		num1=num2;
		num2=temp+num1;
		cout<<" "<<num2;
	}
		
}


















