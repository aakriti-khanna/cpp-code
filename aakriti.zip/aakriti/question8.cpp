#include<iostream>
using namespace std;
int main(){
	int BS,HRA,DA,GS;
	cin>>BS;
	cout<<"enter basic salary of employee : "<<endl;
	if(BS<1500)
	{
		HRA=0.1*BS;
		DA=0.9*BS;
		GS=BS+HRA+DA;
		cout<<"\n"<<"gross salary is : "<<GS;
	}
	else
	{
		HRA=500;
		DA=0.98*BS;
		GS=BS+HRA+DA;
		cout<<"\n"<<"gross salary is : "<<GS;
	}
}
