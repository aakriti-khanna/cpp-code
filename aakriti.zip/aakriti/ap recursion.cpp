//#include<iostream>
//using namespace std;
//int ap(int t1,int d,int n)
//{if(n==1)
//	{	cout<<t1;
//		return 0;
//	}
//		cout<<t1<<" ";
//		t1=t1+d;
//		ap(t1, d, n-1);
//}
//
//
//int main(){
//	int num1,num2,d,n;
//	cout<<"enter any two num to make a series";
//	cin>>num1>>num2>>n;
//	d=num2-num1;
//	ap(num1,d,n);
//}
