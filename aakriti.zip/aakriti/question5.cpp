#include<iostream>
using namespace std;
int main(){
	int R,S,A;
	cin>>R>>S>>A;
	if(R<S && R<A)
	{
		cout<<"\n"<<"R is youngest among 3";
	}

	else if (A<S && A<R)
	{
		cout<<"\n"<<"A is youngest among 3";
	}
	
	else 
	{
		cout<<"\n"<<"S is youngest";
	}
}
