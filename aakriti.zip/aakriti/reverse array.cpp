//#include<iostream>
//using namespace std;
//int main(){
//	int arr1[5]={1,2,3,4,5};
//	int arr2[5];
//	cout<<"\n array : ";
//	int i,j=4;
//	for(i=0;i<5;i++,j--){	
//		arr2[j]=arr1[i];
//	}
//	for(i=0;i<5;i++){
//	cout<<" "<<arr2[i];
//	}
//}

//
//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5]={1,2,3,4,5};
//	int n=5,temp;
//	for(int i=0;i<n/2;i++)
//	{	temp=arr[i];
//		arr[i]=arr[n-i-1];
//		arr[n-i-1]=temp;
//		
//	}
//	for(int i=0;i<n;i++)
//	{
//		cout<<arr[i]<<" ";
//	}
//	
//}



#include<iostream>
using namespace std;
int main(){
	int arr[6]={1,2,3,4,5,6};
	int temp,n=6;
	for(int i=0;i<n;i+=2)
	{
		temp=arr[i];
		arr[i]=arr[i+1];
		arr[i+1]=temp;
	}
	for(int i=0;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
}








