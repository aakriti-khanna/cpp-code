//#include<iostream>
//using namespace std;
//int main(){
//	long long arr[5],max,i;
//	cout<<"enter any 5 num";
//	for(int i=0;i<5;i++)
//	{
//		cin>>arr[i];
//	}
//	max=arr[0];
//	for(int i=0;i<5;i++)
//	{	if(max< arr[i])
//		{
//			max= arr[i];
//		}
//		
//	}
//	cout<<"max is"<<max;
//	
//}








//using namespace std;
//int main(){
//	int i,n;
//	int arr[5]={0,2,1,2,0};
//	int count0=0,count1=0,count2=0;
//	for(int i=0;i<n;i++)
//	{
//		cin>>arr[i];
//	}
//	
//	for(int i=0;i<n;i++){
//	if(arr[i]==0)
//	{	count0++;	
//	}
//	else if(arr[i]==1)
//	{	count1++;
//	}
//	else 
//	{	count2++;
//	}
//}
//	for(int i=0;i<count0;i++){
//		arr[i]=0;
//	}	
//	for(int i=0;i<count1;i++){
//		arr[i]=1;
//	}
//	for(int i=0;i<count2;i++)
//	{
//		arr[i]=2;
//	}
//	}
		











