#include<iostream>
using namespace std;
int main(){
	int arr[2][5]={{1,2,3,4,5},{6,7,8,9,10}};
	cout<<"\n array : ";
	for(int stu=0;stu<2;stu++)
	{
		cout<<"\n marks of student 1 :";
		for(int sub=0;sub<5;sub++)
	{  
		cout<<" "<<arr[stu][sub];
	}
		
	}
}
