//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	for(int i=1;i<=n;i++){
//		for(int space=1;space<=n-i;space++)
//		{
//			cout<<" ";
//		}
//		int num=i;
//		for(int j=1;j<=i;j++)
//		{
//			cout<<num<<" ";
//			num++;
//		}
//		num=(2*i)-2;
//		for(int j=1;j<=i-1;j++)
//		{
//			cout<<num<<" ";
//			num--;
//		}
//		
//		cout<<endl;
//		
//	}
//	
//}


//int main(){
//	int n;
//	cin>>n;
//	for(int i=2;i<=n;i++){
//		bool flag=true;
//		for(int j=2;j<i;j++){
//			if(i%j==0){
//				flag =false ;
//				
//				break;
//			}
//		}
//		if(flag)
//		{
//			cout<<i;
//		}
//	}
//}

//
//int main(){
//	int n;
//	cin>>n;
//	int even=0,odd=1;
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=i;j++){
//			if(i%2==0){
//			
//			if(j%2==0)
//			{
//				cout<<1;
//			}
//			else{
//				cout<<0;
//			}
//		}
//		
//		else{
//			
//			if(j%2==0)
//			{
//				cout<<0;
//			}
//			else{
//				cout<<1;
//			}
//			
//		}
//	}
//		cout<<endl;
//	}
//}

//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	cout<<1<<endl;
//	for(int row=2;row<=n;row++){
//		for(int col=1;col<=row;col++){
//		
//		if(col==1||col==row)
//		{	
//			cout<<row-1	;
//		}
//		else
//		{
//			cout<<0;
//		}
//	}
//		cout<<endl;
////	}
//	
//}


//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	n=(n+1)/2;
//	for(int i=1;i<=(2*n)-1;i++)
//	{
//		cout<<"*"<<" ";
//	}
//	cout<<endl;
//	for(int i=2;i<=n;i++){	
//	for(int j=i;j<=n;j++){
//		cout<<"*"<<" ";
//	}	
//	for(int k=1;k<=(2*i)-3;k++)
//	{
//		cout<<" "<<" ";
//	}
//	for(int j=i;j<=n;j++)
//	{
//		cout<<"*"<<" ";
//	}	
//	cout<<endl;
//	}
//	for(int i=n-1;i>=2;i--){	
//	for(int j=i;j<=n;j++){
//		cout<<"*"<<" ";
//	}	
//	for(int k=1;k<=(2*i)-3;k++)
//	{
//		cout<<" "<<" ";
//	}
//	for(int j=i;j<=n;j++)
//	{
//		cout<<"*"<<" ";
//	}
//	cout<<endl;
//
//	for(int i=1;i<=(2*n)-1;i++)
//	{
//		cout<<"*"<<" ";
//	}	
//	
//}
//
//}
//
//







//
//#include<iostream>
//using namespace std;
//int main () {
//	int n;
//	cin>>n;
//	for(int i=1;i<=n;i++){
//	
//		for(int j=1;j<i;j++){			
//			cout<<i;
//		}
//			
//		for( int j=i;j<=n;j++){
//			cout<<j;
//				
//		}
//			
//		cout<<endl;
//	}
//}


//#include<iostream>
//using namespace std;
//int main () {
//	int n;
//	cin>>n;
//	n=n+1/2;
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<n;j++){
//			cout<<"*"<<" ";
//		}
//		for(int j=i;j<=n;j++){
//			cout<<" ";
//		}
//		cout<<endl;
//}
//}


//
//#include<iostream>
//using namespace std;
//int main(){
//	int  o=0,e=0,n;
//	cin>>n;
//	int i=1;
//	while(n!=0){
//		int digit=n%10;
//		if(i%2==0){
//			e=e+digit;
//		}
//		else{
//			o=o+digit;
//		}
//		n=n/10;
//		i++;
//	}
//	cout<<" ODD :"<<o<<endl;
//	cout<<"EVEN : "<<e<<endl;
//}


//
//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	for(int i=1;i<=n;i++){
//		for(int k=1;k<=)
//		for(int j=1;j<=n-i;j++){
//			cout<<"*"<<" ";
//		}
//		cout<<endl;
//	}
//}



//
//#include<iostream> 
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	for(int i=n;i>0;i--){
//		for(int k=n-i;k>0;k--)
//		{
//			cout<<" ";
//		}
//		for(int j=i;j>0;j--)
//		{
//			cout<<"*"<<" ";
//		}
//		cout<<endl;
//	}
//		
//}


//
//#include<iostream>
//using namespace std;
//int main(){
//	
//	
//}

//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	int k=(n+1)/2;
//	for(int i=1;i<=k;i++){
//		for(int j=1;j<=k;j++){
//			if(j==1||j==k||i==k)
//			{
//				
//				cout<<"*"<<" ";
//			}
//			else{
//				cout<<"  ";
//			}
//		}
//		for(int j=k; j<n; j++){
//			if(i==1||i==k){
//				cout<<"* ";
//			}else{
//				cout<<"  ";
//			}
//		}
//		cout<<endl;
//}
//	for(int i=k;i<=n;i++){
//		for(int j=k;j<=n;j++){
//			if(i==n||j==n){
//			
//		
//				cout<<"*"<<" ";
//			}
//			else{
//				cout<<"  ";
//			}
//		}
//		for(int j=1;j<=n;j++){
//			if(j==n-2){
//				cout<<"*"<<" ";
//			}
//			else{
//				cout<<" ";
//			}
//		}
//		cout<<endl;
//}
//}
//	

//
//#include<iostream>
//using namespace std;
//int main(){
//	int n;
//	cin>>n;
//	int count=0;
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=i;j++){
//			
//			if(j==1||j==i)
//			{
//				cout<<1;
//			}
//		
//		for(int j=1;j<=i;j++){
//		
//			if(j==2||j==i-1)
//			{
//				cout<<i;
//			}
//	
//	}
//
//}
//	cout<<endl;
//}
//}
//	







	
		
	
	
#include<iostream>
using namespace std;
int main(){
	int arr[100];
	int n;
	cin>>n;
	for(int i=1;i<n;i++)
	{
			cin>>arr[i];
	}
	for(int i=1;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;
}
		








