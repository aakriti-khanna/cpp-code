//#include<iostream>
//using namespace std;
//int main(){
//	int arr[5]={1,2,3,4,5};
//	int n=5,temp;
//	for(int i=0;i<n;i++)
//	{	temp=arr[i];
//		arr[i]=arr[n-i-1];
//		arr[n-i-1]=temp;
//		
//	}
//	for(int i=0;i<n;i++)
//	{
//		cout<<arr[n-i-1]<<"  ";
//	}
//	
//}
