//#include<iostream>
//#include<vector>
//using namespace std;
//int main(){
//	vector<int> v;
//	int ele;
//	int val=1;
//	while(val)
//	{	cout<<"\n enter element";
//		cin>>ele;
//		v.push_back(ele);
//		cout<<"\n do u want to run it 1/0 ";
//		cin>>val;
//	}
//	cout<<"\n vector size : "<<v.size();
//	cout<<"\n vector : ";
//	for(int i ;i<v.size();i++)
//	{
//		cout<<" "<<v[i];
//	}
//
//	
//	
//}



#include<iostream>
#include<vector>
using namespace std;
void input(vector<int> &v){
//	vector<int> v;
	int ele;
	int val=1;
	while(val)
	{	cout<<"\n enter element";
		cin>>ele;
		v.push_back(ele);
		cout<<"\n do u want to run it 1/0 ";
		cin>>val;
	}
	
	
	
}
void display( vector<int> &v){
	cout<<"\n vector size : "<<v.size();
	cout<<"\n vector : ";
	for(int i ;i<v.size();i++)
	{
		cout<<" "<<v[i];
	}
	
}
int main(){
	vector<int> vec;
	input(vec);
	display(vec);
	
	}




