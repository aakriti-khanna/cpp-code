#include<iostream>
using namespace std;
int main(){
	int a;
	cout<<"enter the year";
	cin>>a;
	if(a%4==0)
	{
		cout<<"\n"<<"it is a leap year";
	}
	else
	{
		cout<<"\n"<<"it is not a leap year";
	}
}
