#include<iostream>
using namespace std;
int main(){
	int a;
	cin>>a;
	cout<<"enter a number:";
	if( a%2==0)
	{
		cout<<"\n"<<a<<"number is even";
	}
	else
	{
		cout<<"\n"<<a<<"number is odd";
	}
}
