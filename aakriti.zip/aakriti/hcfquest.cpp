#include<iostream>
using namespace std;
int main(){
	int a1,a2,b,temp,res=1;
	cout<<"enter two numbers :"<<endl;
	cin>>a1>>a2;
	(a1 > a2) ? b = a2 : b = a1;
	while(b>0)
	{
		if( a1%b==0 && a2%b==0 ){
			cout<<"HCF of two numbers are : "<< b;		
			break;
		}
		b--;
	}
}
